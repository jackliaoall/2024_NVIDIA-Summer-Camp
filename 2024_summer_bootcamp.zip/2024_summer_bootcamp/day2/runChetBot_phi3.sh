wasmedge --dir .:. --nn-preload default:GGML:AUTO:Phi-3-mini-4k-instruct-q4.gguf llama-api-server.wasm -p phi-3-chat
